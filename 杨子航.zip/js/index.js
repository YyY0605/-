window.onscroll = function() {scrollFunction()};
 
function scrollFunction(){
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("back-top").style.display = "block";
    } else {
        document.getElementById("back-top").style.display = "none";
    }
}
 
function back_top() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}